package br.inatel.dm110.hello.beans;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.Session;

import br.inatel.dm110.api.StateTO;

@Stateless
public class IbgeMessageSender {

	@Resource(lookup = "java:/ConnectionFactory")
	private ConnectionFactory connectionFactory;

	@Resource(lookup = "java:/jms/queue/ibgequeue")
	private Queue queue;

	public void sendObjectMessage(StateTO state) {

		try (Connection connection = connectionFactory.createConnection();
				Session session = connection.createSession();
				MessageProducer producer = session.createProducer(queue);) {

			ObjectMessage objMessage = session.createObjectMessage(state);

			producer.send(objMessage);

		} catch (JMSException e) {
			System.err.println("Erro enviando mensagem: " + state.getNome());
			e.printStackTrace();
			throw new RuntimeException(e);
		}

	}

}
