package br.inatel.dm110.api;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/calc")
public interface CalculatorService {

	@GET
	@Path("/soma/{op1}/{op2}")
	@Produces(MediaType.TEXT_HTML)
	String soma(@PathParam("op1") String op1,
			@PathParam("op2") String op2);
}
