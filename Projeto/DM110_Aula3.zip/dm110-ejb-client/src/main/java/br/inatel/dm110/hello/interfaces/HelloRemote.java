package br.inatel.dm110.hello.interfaces;

public interface HelloRemote extends Hello {

}
