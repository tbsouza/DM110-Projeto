package br.inatel.dm110.hello.interfaces;

public interface Hello {

	String sayHello(String name);
	
}
