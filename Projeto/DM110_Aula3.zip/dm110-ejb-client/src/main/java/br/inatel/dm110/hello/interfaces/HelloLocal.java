package br.inatel.dm110.hello.interfaces;

public interface HelloLocal extends Hello{

}
