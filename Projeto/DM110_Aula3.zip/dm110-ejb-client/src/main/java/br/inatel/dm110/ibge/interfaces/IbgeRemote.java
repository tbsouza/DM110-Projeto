package br.inatel.dm110.ibge.interfaces;

public interface IbgeRemote extends Ibge {

}
