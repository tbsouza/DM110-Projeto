package br.inatel.dm110.ibge.interfaces;

public interface IbgeLocal extends Ibge {

}
